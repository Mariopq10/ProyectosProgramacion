package excepciones;

public class NoEsImagenException extends Exception {

}
